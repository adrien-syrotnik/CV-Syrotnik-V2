import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Animator extends PApplet {

 PImage save[] = new PImage[0];
 PImage savex;
 boolean[] touche = new boolean[255555];
 boolean press;
 float mouseX2,mouseY2;
 int r,g,b;
 PImage backup;
 boite[] couleur = new boite[10];
 int timeanimation=0;
 
 
 PImage loopimage,normalimage,arrow,saveicon,downloadicon;
 boolean loopmode=true;
 boolean movemode;
 hommebaton[] homme = new hommebaton[1];
 //hommebaton homme = new hommebaton(600,350);
public void setup() {
 
 loopimage = loadImage("loop.png");
 normalimage = loadImage("normal.png");
 arrow = loadImage("arrow.png");
 saveicon = loadImage("save.png");
 downloadicon = loadImage("download.png");
 
 
 homme[0] = new hommebaton(600*homme.length,350,0);
 frameRate(150);
 size(1280,720); 
 background(255);
 couleur[0] = new boite(PApplet.parseInt(width)-150,PApplet.parseInt(height)-150,50,50,255,255,255);
 couleur[1] = new boite(PApplet.parseInt(width)-150,PApplet.parseInt(height)-250,50,50,0,0,0);
 
 

}



int imgfaites = 0;
boolean intro;
boolean drawintro;

public void draw() {
  
//INTRO

if(intro==false) {
  
 noStroke();
 fill(200);
 if(mouseX>width/4 && mouseX<3*width/8 && mouseY>width/8 && mouseY<2*width/8) { fill(0);}
 rect(width/4,width/8,width/8,width/8);
 
 fill(200);
 if(mouseX>5*width/8 && mouseX<6*width/8 && mouseY>width/8 && mouseY<2*width/8) { fill(0);}
 rect(5*width/8,width/8,width/8,width/8);
  
 textSize(30);
 fill(255,0,0);
 textAlign(CENTER);
 text("No Draw",width/4+width/16,width/8+width/16);
 text("MODE",width/4+width/16,width/8+width/16+width/40);
 
 text("Draw",5*width/8+width/16,width/8+width/16);
 text("MODE",5*width/8+width/16,width/8+width/16+width/40);
  
 
 if(mousePressed==true && mouseX>5*width/8 && mouseX<6*width/8 && mouseY>width/8 && mouseY<2*width/8) { intro=true; movemode=false; background(255);}
 
 if(mousePressed==true && mouseX>width/4 && mouseX<3*width/8 && mouseY>width/8 && mouseY<2*width/8) { intro=true; movemode=true; background(255);}
 
 
}

  else {
//FIN INTRO





//CARRE EN HAUT A GAUCHE
fill(255);
rect(0,0,100,100);
textSize(50);
fill(0);
text(save.length,50,70);

//OUTIL DE DESSIN
  if(movemode==false) {
    
if(mousePressed==true && mouseButton == LEFT && drawintro==true) {

if(r==255 && g==255 && b==255) {
strokeWeight(15);
}
else {
strokeWeight(10);
}
stroke(r,g,b);
line(mouseX,mouseY,mouseX2,mouseY2);
stroke(0);
}



couleur[0].affichage();
couleur[1].affichage();

  
image1();

}



//save l'image actuelle

if(touche[ENTER]==true && press==false && pressedimg==false) {
  
    if(movemode==true) { background(255); afficherbaton(false);}
  
    press=true;
 
    savex = get(101,101,1024,576);
    save = (PImage[])expand(save,save.length+1);
    save[imgfaites]=savex;
    save[imgfaites].save("test1/"+str(imgfaites)+".jpg");
    imgfaites++;
}

//TEster sur un gif en ligne
if(touche['g']==true && press==false) {
link("https://ezgif.com/maker");
press=true;
}


  
//METHODE NON DESSINER  
if(movemode==true && touche['p'] == false) {background(255); afficherbaton(false);}
  
  
  
  
  //PLAY
  
  if(touche['p']==false || timeanimation>=(save.length-1)*10) { timeanimation=0;}
  if(touche['p']==true) {
    
    timeanimation++;
    if(timeanimation%10==0) {
     image(save[timeanimation/10],100,100);
    }
    
    
  }
  
  
  
 
 //COORDONNES CLAVIER (s / l)
  //Save les coordonn\u00e9es
  if(touche['s']==true && press==false) {
  press=true;
  savecoor();
  }
  //Joue les coordonn\u00e9es
  if(touche['l']==true) {
  if(press==false) {play=0; press=true; for(int i=0;i<homme.length;i++) {resetperso(i);}}
  loadcoor();          
  
   }
   
   
 //SAVE TEXTE FILE
   if(touche['7']==true && press==false) {
    press=true;
    selectInput("Choisissez le .txt", "savefile");
   }
   
   if(touche['8']==true && press==false) {
    press=true;
    selectInput("Choisissez le .txt", "loadfile");
   }
   
//LOOP MODE
if(mouseX>width-150 && mouseX<width-100 && mouseY>50 && mouseY<100) { tint(100,80); }
if(loopmode==true) {
image(loopimage,width-150,50,50,50);
}
else {
image(normalimage,width-150,50,50,50);
}
tint(255);
   
   
//INTERFACE ECRAN PRINCIPAL
fill(0,0);
strokeWeight(1);
rect(100,100,1025,577);


if(touche['r']==true) {
   background(255);
}

if(touche[26] == true) {
  image(backup,101,101);
}


interfacedroite();
changeframe();

  
  }

  
  
  
mouseX2=mouseX;
mouseY2=mouseY;
}




class boite {
  int x,y,x2,y2,R,G,B;
  boolean c=true;
  boolean pressed;
  boite(int xx,int yx,int x2x,int y2x,int Rx,int Gx,int Bx) {
    x= xx;
    y= yx;
    x2=x2x;
    y2=y2x;
    R=Rx;
    G=Gx;
    B=Bx;
  }
  
  public void affichage() {
   
   strokeWeight(1);
   fill(R,G,B);
   
   
   if(mouseX>x && mouseX<x+x2 && mouseY>y && mouseY<y+y2) {
     
     if(mousePressed == true) {
      pressed=true;
     }
     else if(pressed==true && c==true) {
       pressed=false;
       r = R; g = G; b = B;
       
     }
     
   }
   rect(x,y,x2,y2);
   
   
  }
  
  
}

boolean CTRL,DEL;


public void keyPressed()  {
  if(toucheactive==true) {touche[key]=true;}
  
  if(key=='m' && toucheactive==true) { if(movemode==true) {movemode=false;} else {movemode=true;}}
  if(keyCode==17) {CTRL=true;}
  if(keyCode==8) {DEL=true;}
  
  
}

public void keyReleased() { 
  
  press=false;
  
  
if(keyCode==17) {CTRL=false;}
if(keyCode==8) {DEL=false;}

  touche[key]=false;
  
  
  if(toucheactive==true) {
  if(key=='x') {
    homme = (hommebaton[])expand(homme,homme.length+1);
    homme[homme.length-1] = new hommebaton(200*homme.length,350,homme.length-1);
  }
 }
 
 key=0;
 
}


public void mousePressed() {
 
  backup = get(101,101,1024,576);
  
  if(pressedimg==true) {
 
  background(255);
  image(savex,101,101);
  
  }
}

public void mouseReleased() {
  
  //loadcoor
  if(mouseX>980 && mouseX<1020 && mouseY>678 && mouseY<678+40) {
     
  selectInput("Choisissez le .txt", "loadfile");
   
  }
  
  //savecoor
  if(mouseX>1050 && mouseX<1085 && mouseY>681 && mouseY<681+35) {
   
  selectInput("Choisissez le .txt", "savefile");
    
  }
  
  
  /*if(intro==true && movemode==true) {
  background(255); afficherbaton(true);
  }*/
  
  //fleche gauche
  if(mouseX>100 && mouseX<150 && mouseY>70 && mouseY<100 && bandeimage>0) { bandeimage--;  }

  //fleche droite
  if(mouseX>50+1025 && mouseX<100+1025 && mouseY>70 && mouseY<100 && image >= (bandeimage+1)*10) { bandeimage++; }
  
  
  
  //Loopmode
  if(mouseX>width-150 && mouseX<width-100 && mouseY>50 && mouseY<100 && mouseButton == LEFT) {
    if(loopmode==true) {loopmode=false;} else {loopmode=true;}
  }
  
  
  
  
  
  
  
  if(CTRL==false) {
  selecpoint = false;
  
  for(int i=0;i<homme.length;i++) {
  for(int y=0;y<12;y++) {
  homme[i].picknumber[y]=false;
   }
  }
 }
 
 
  if(drawintro==false && intro==true) {drawintro=true;}
  
   if(pressedimg==true) {
 
  savex = get(101,101,1024,576);
  
  image(save[imgfaites-1],101,101);
  
  }
}
boolean selecpoint;

class hommebaton {
  
 float[] pointx = new float[12];
 float[] pointy = new float[12];
 float tailletete=40;
 boolean pick;
 boolean[] picknumber= new boolean[12];
 int num;
 hommebaton(int x,int y,int n) {
  picknumber[0]=false;
  
  num = n; 
  
  pointx[0]=x;
  pointy[0]=y;
  
  pointx[1]=x;
  pointy[1]=y-60;
  
  pointx[2]=x;
  pointy[2]=y+80;
  
  
  pointx[3]=x-60;
  pointy[3]=y;
  
  pointx[4]=x-120;
  pointy[4]=y;
  
  pointx[5]=x+60;
  pointy[5]=y;
  
  pointx[6]=x+120;
  pointy[6]=y;
  
  pointx[7]=x-30;
  pointy[7]=y+40+80;
  
  pointx[8]=x-30;
  pointy[8]=y+100+80;
  
  pointx[9]=x+30;
  pointy[9]=y+40+80;
  
  pointx[10]=x+30;
  pointy[10]=y+100+80;
  
  pointx[11]=x;
  pointy[11]=y-60;
 }
 
 public void affichage(boolean rondaffichage) {
   
  //555 = CONTROL
   if(CTRL==true) { selecpoint=false;}
   
   
   for(int i=0;i<11;i++) {
     
     if(mousePressed==true && mouseX>pointx[i]-5 && mouseX<pointx[i]+5 && mouseY>pointy[i]-5 && mouseY<pointy[i]+5 && selecpoint==false) {
       
       selecpoint = true; 
       picknumber[i] = true;
       
     }
     
    
      
      //if(pointy[i]<677) {pointy[i]++; background(255);}
      
      
      if(picknumber[i] == true && CTRL==false && mousePressed==true) {
       //pointx[i]=mouseX;
       //pointy[i]=mouseY;
       pointx[i]+=mouseX-mouseX2;
       pointy[i]+=mouseY-mouseY2;
       
     }
      
      
   }
   
   
     
    
   
   //Affichage hors sortie vid\u00e9o
   if(rondaffichage==true && selecimage>0 && coordonnes[num][selecimage-1][0][0]>1) {
   strokeWeight(15);
   stroke(0,50);
   fill(0,50);
   line(coordonnes[num][selecimage-1][0][0],coordonnes[num][selecimage-1][1][0],coordonnes[num][selecimage-1][0][1],coordonnes[num][selecimage-1][1][1]);
   line(coordonnes[num][selecimage-1][0][0],coordonnes[num][selecimage-1][1][0],coordonnes[num][selecimage-1][0][2],coordonnes[num][selecimage-1][1][2]);
   line(coordonnes[num][selecimage-1][0][0],coordonnes[num][selecimage-1][1][0],coordonnes[num][selecimage-1][0][3],coordonnes[num][selecimage-1][1][3]);
   line(coordonnes[num][selecimage-1][0][0],coordonnes[num][selecimage-1][1][0],coordonnes[num][selecimage-1][0][5],coordonnes[num][selecimage-1][1][5]);
   line(coordonnes[num][selecimage-1][0][2],coordonnes[num][selecimage-1][1][2],coordonnes[num][selecimage-1][0][7],coordonnes[num][selecimage-1][1][7]);
   line(coordonnes[num][selecimage-1][0][2],coordonnes[num][selecimage-1][1][2],coordonnes[num][selecimage-1][0][9],coordonnes[num][selecimage-1][1][9]);
  
   
   //point en plus
   //line(pointx[2],pointy[2],pointx[11],pointy[11]);
   
   //tete
   ellipse(coordonnes[num][selecimage-1][0][1],coordonnes[num][selecimage-1][1][1]-tailletete+tailletete/3,tailletete,tailletete);
   
   for(int i=3;i<10;i+=2) {
   line(coordonnes[num][selecimage-1][0][i],coordonnes[num][selecimage-1][1][i],coordonnes[num][selecimage-1][0][i+1],coordonnes[num][selecimage-1][1][i+1]);
   }
   strokeWeight(1); 
     
   }
   
   
   
   
   if(pointx[0]>1) {
   
   strokeWeight(15);
   stroke(0);
   fill(0);
   line(pointx[0],pointy[0],pointx[1],pointy[1]);
   line(pointx[0],pointy[0],pointx[2],pointy[2]);
   line(pointx[0],pointy[0],pointx[3],pointy[3]);
   line(pointx[0],pointy[0],pointx[5],pointy[5]);
   line(pointx[2],pointy[2],pointx[7],pointy[7]);
   line(pointx[2],pointy[2],pointx[9],pointy[9]);
   
   //point en plus
   //line(pointx[2],pointy[2],pointx[11],pointy[11]);
   
   //tete
   ellipse(pointx[1],pointy[1]-tailletete+tailletete/3,tailletete,tailletete);
   
   for(int i=3;i<10;i+=2) { 
   line(pointx[i],pointy[i],pointx[i+1],pointy[i+1]);
   }
   strokeWeight(1);
   
   for(int i=0;i<11;i++) {
     fill(0,244,245);
     
 
     
     //Affichage hors sortie vid\u00e9o
     if(rondaffichage==true) {
       if(picknumber[i]==true) {fill(255,200,0);}
       
     ellipse(pointx[i],pointy[i],10,10);
     }
   }
  }
   
   
 }
 //fin du void
  
}
//fin class

public void afficherbaton(boolean bool) {
  
 for(int i=0;i<homme.length;i++) { 
  homme[i].affichage(bool);
 }
}
int reduction = 10;
int bandeimage=0;


int selecimage=0;

public void changeframe() {
  
  if(mouseX>100 && mouseX<150 && mouseY>70 && mouseY<100) { tint(255,80); }
  
  //RECTANGLE NOIR
  if(bandeimage==0) {fill(0,230); rect(100,70,50,30);}
  if(image < (bandeimage+1)*10) {fill(0,230); rect(1075,70,50,30);}
  
  pushMatrix();
  
  translate(150,110);
  rotate(PI);
  image(arrow,0,0,50,50);
  
  popMatrix();
  
  tint(255);
  
  if(mouseX>50+1025 && mouseX<100+1025 && mouseY>70 && mouseY<100) { tint(255,80); }
  image(arrow,100+1025-50,60,50,50);
  tint(255);
  
  
 for(int p=0;p<homme.length;p++) {
   
  for(int i=0;i<10;i++) {
    
    if(i<=image-bandeimage*10) {
    
    
    //detection click sur les frames
    if(mouseX>100+1025.00f/10*i && mouseX<100+1025.00f/10*i+1025.00f/10 && mouseY>9 && mouseY<69 && mousePressed==true) {
     selecimage=i+bandeimage*10;
     majperso();
  }
    
    pushMatrix();
    
    fill(0,0);
    translate(100+1025.00f/10*i,0);
    rect(0,9,1025.00f/10,60);
    
   if(coordonnes[p][i+bandeimage*10][0][0]>1) {
   
   strokeWeight(2);
   stroke(0);
   fill(0,50);
   line(coordonnes[p][i+bandeimage*10][0][0]/reduction,coordonnes[p][i+bandeimage*10][1][0]/reduction,coordonnes[p][i+bandeimage*10][0][1]/reduction,coordonnes[p][i+bandeimage*10][1][1]/reduction);
   line(coordonnes[p][i+bandeimage*10][0][0]/reduction,coordonnes[p][i+bandeimage*10][1][0]/reduction,coordonnes[p][i+bandeimage*10][0][2]/reduction,coordonnes[p][i+bandeimage*10][1][2]/reduction);
   line(coordonnes[p][i+bandeimage*10][0][0]/reduction,coordonnes[p][i+bandeimage*10][1][0]/reduction,coordonnes[p][i+bandeimage*10][0][3]/reduction,coordonnes[p][i+bandeimage*10][1][3]/reduction);
   line(coordonnes[p][i+bandeimage*10][0][0]/reduction,coordonnes[p][i+bandeimage*10][1][0]/reduction,coordonnes[p][i+bandeimage*10][0][5]/reduction,coordonnes[p][i+bandeimage*10][1][5]/reduction);
   line(coordonnes[p][i+bandeimage*10][0][2]/reduction,coordonnes[p][i+bandeimage*10][1][2]/reduction,coordonnes[p][i+bandeimage*10][0][7]/reduction,coordonnes[p][i+bandeimage*10][1][7]/reduction);
   line(coordonnes[p][i+bandeimage*10][0][2]/reduction,coordonnes[p][i+bandeimage*10][1][2]/reduction,coordonnes[p][i+bandeimage*10][0][9]/reduction,coordonnes[p][i+bandeimage*10][1][9]/reduction);
  
   
   //point en plus
   //line(pointx[2],pointy[2],pointx[11],pointy[11]);
   
   //tete
   ellipse(coordonnes[p][i+bandeimage*10][0][1]/reduction,(coordonnes[p][i+bandeimage*10][1][1]-homme[0].tailletete+homme[0].tailletete/3)/reduction,homme[0].tailletete/reduction,homme[0].tailletete/reduction);
   
   for(int y=3;y<10;y+=2) {
   line(coordonnes[p][i+bandeimage*10][0][y]/reduction,coordonnes[p][i+bandeimage*10][1][y]/reduction,coordonnes[p][i+bandeimage*10][0][y+1]/reduction,coordonnes[p][i+bandeimage*10][1][y+1]/reduction);
   }
   strokeWeight(1); 
   
   }
  
   popMatrix();
    }
  }
 }
 
 if(selecimage<(bandeimage+1)*10) {
 strokeWeight(5);
 stroke(255,0,0); 
 rect((selecimage-bandeimage*10)*1025.00f/10+100,9,1025.00f/10,60);
 stroke(0);
 }
}
//Tableau a 4 dimensions : 12 points [x] [y], moment (1 ere save, 2\u00e8me etc..) [t], et personnage s'il y'en a plsuieurs
float[][][][] coordonnes = new float [5][1000][2][12];
int image;
int play;
float xdif, ydif;

int timerefresh=20;


public void savecoor() {
  for(int y=0;y<homme.length;y++) {
  for (int i=0; i<12; i++) {
    coordonnes[y][selecimage][0][i]=homme[y].pointx[i];
    coordonnes[y][selecimage][1][i]=homme[y].pointy[i];
  }
 }
 
 if(selecimage==image) {
  image++;
 }
  selecimage++;
  println(image);
  
}


public void loadcoor() {


  play++;

  if (play/timerefresh==image) {
    play=0; 
    xdif=0; 
    ydif=0;
  }

for(int y=0;y<homme.length;y++) {

  for (int i=0; i<12; i++) {

    if (play==0) {
      resetperso(y);
    }


//CLASSIC PLAY
if(loopmode==false) {
    if (play<(image-1)*timerefresh) { 
      xdif = coordonnes[y][play/timerefresh][0][i]-coordonnes[y][play/timerefresh+1][0][i];     
      ydif = coordonnes[y][play/timerefresh][1][i]-coordonnes[y][play/timerefresh+1][1][i];
    }
   }
//LOOP PLAY
if(loopmode==true) {
    if (play<(image-1)*timerefresh) { 
      xdif = coordonnes[y][play/timerefresh][0][i]-coordonnes[y][play/timerefresh+1][0][i];     
      ydif = coordonnes[y][play/timerefresh][1][i]-coordonnes[y][play/timerefresh+1][1][i];
    }
    if (play>=(image-1)*timerefresh) { 
      xdif = coordonnes[y][play/timerefresh][0][i]-coordonnes[y][0][0][i];     
      ydif = coordonnes[y][play/timerefresh][1][i]-coordonnes[y][0][1][i];
    }
  }
  
//MODIFICATION COORDONNEES  
    homme[y].pointx[i]-=xdif/timerefresh;
    homme[y].pointy[i]-=ydif/timerefresh;
  
  
 }
}
  //background(255);
  //afficherbaton(false);
}

public void resetperso(int num) {

  for (int i=0; i<12; i++) {


    homme[num].pointx[i]=coordonnes[num][0][0][i];
    homme[num].pointy[i]=coordonnes[num][0][1][i];
  }
}


public void majperso() {
  
  
  
 for(int p=0;p<homme.length;p++) {
  for (int i=0; i<12; i++) {

  if(selecimage<image) {
    homme[p].pointx[i]=coordonnes[p][selecimage][0][i];
    homme[p].pointy[i]=coordonnes[p][selecimage][1][i];
   }
  else if(image>0){
   homme[p].pointx[i]=coordonnes[p][image-1][0][i];
   homme[p].pointy[i]=coordonnes[p][image-1][1][i];
   }
  }
 }
}



public void resettotal() {
  
  image=0;
  selecimage=0;
  bandeimage=0;
  
  
   for(int p=0;p<homme.length;p++) {
   for(int m=0;m<1000;m++) {
  for (int i=0; i<12; i++) {


    coordonnes[p][m][0][i]=0;
    coordonnes[p][m][1][i]=0;
   
  
   }
  
  }
 }
}
inputbox boxvitesseaffichage = new inputbox(1150,200,100,30,true,"20","Vitesse Animation");
inputbox emplacementsauvegarde = new inputbox(550,683,400,30,false,"Save"," ");
boolean toucheactive=true;

String textfile;
public void interfacedroite() {
  
  cursor(ARROW);
  
  boxvitesseaffichage.affichage();
  timerefresh=PApplet.parseInt(boxvitesseaffichage.texte);
  
  fill(0);
  textSize(30);
  text("Text File (Save / Load) : ",350,708);
  emplacementsauvegarde.affichage();
  //textfile = "SaveProject/" + emplacementsauvegarde.texte + ".txt";
  fill(255);
  

if(mouseX>980 && mouseX<1020 && mouseY>678 && mouseY<678+40) { tint(100); }

image(downloadicon,980,678,40,40);
tint(255);


if(mouseX>1050 && mouseX<1085 && mouseY>681 && mouseY<681+35) { tint(100); }

image(saveicon,1050,681,35,35);
tint(255);
  
  
  
  
  
  
  
  
  
}





class inputbox {
  int x,y,x2,y2;
  String texte ="";
  String description;
  int barre;
  boolean chiffre;
  inputbox(int xx,int yx,int x2x, int y2x,boolean c,String t,String d) {
    
  texte=t;
  description = d;
  chiffre=c;
  x = xx;
  y = yx;
  x2 = x2x;
  y2 = y2x;
  }
  
  
  public void affichage() {
   
    
   if(mouseX>x && mouseX <x+x2 && mouseY>y && mouseY<y+y2) { 
     //cursor(TEXT); 
     if(mousePressed==true) {barre=1;}
 }
 else {if(mousePressed==true) {barre=0; toucheactive=true;}} 
 
 
 
 
   
   fill(0);
   rect(x,y,x2,y2);
   fill(255);
   rect(x+y2/10,y+y2/10,x2-y2/10,y2-y2/10);
   
   fill(0);
   
   if(barre>0) {barre++; toucheactive=false;
 
 if(DEL==true && press==false && texte.length()>0) { texte = texte.substring(0,texte.length()-1); press=true;}

 if(keyPressed==true && press==false && DEL==false && keyCode!=16 && keyCode != 20 && key!=0) { 
 
 if(chiffre==true && PApplet.parseInt(key)>=48 && PApplet.parseInt(key)<=57) {
   texte += key; press=true;
 }
 
 if(chiffre==false) {
 texte += key; press=true;
 }
 
 
 
   }
 
 }
 
   
   if(barre>100) {barre=1;}
   
   if(barre>50) { rect(x+x2/2+texte.length()*y2/4,y+9*y2/10,2,-7*y2/10);}
   
   //description
   textSize(x2*2/description.length());
   text(description,x+x2/2,y-x2/description.length());
   
   textSize(y2);
   text(texte,x+x2/2,y+9*y2/10);
   fill(255);
   
   

   
   
    
  
  
  
  }
  
}


  


public void loadfile(final File selection) {


resettotal();
textfile = selection.getPath();  
  
String[] ligneactu = loadStrings(textfile);

if(ligneactu!=null) {
  
  for(int i=0;i<ligneactu.length;i++) {
String[] list = split(ligneactu[i], ' ');
image++;

while(homme.length<list.length/24) { homme = (hommebaton[])expand(homme,homme.length+1);  homme[homme.length-1] = new hommebaton(200*homme.length,350,homme.length-1); }



for(int p=0;p<list.length/24;p++) {
  
    for(int l=0;l<24;l++) {
    
      coordonnes[p][i][l%2][l/2]=PApplet.parseInt(list[p*24+l]);
    
    }
   }
  }
   majperso();
 }
 else {println("ERROR");}
  
}


public void savefile(final File selection) {
  
  textfile = selection.getPath() + ".txt"; 
  
  String[] ligneactu = new String[1];  
  
  //nom du fichier (pour l'instant un seul
  for(int i=0;i<image;i++) {
    
    if(ligneactu.length<i+1) { ligneactu = (String[])expand(ligneactu,ligneactu.length+1); }
    
   ligneactu[i]="";
  for(int y=0;y<homme.length;y++) {
    
    if(y>0) {ligneactu[i] += " ";}
    
     for(int x=0;x<12;x++) {
    
    if(x>0) { ligneactu[i] += " "; }
    ligneactu[i] += str(PApplet.parseInt(coordonnes[y][i][0][x])) +" "+ str(PApplet.parseInt(coordonnes[y][i][1][x]));
     }
   }
  }
  saveStrings(textfile, ligneactu);
  
}
boolean pressedimg;


public void image1() {
 if(touche['1']==true && pressedimg==false && save.length>0) {
  pressedimg=true;
  
  
  savex = get(101,101,1024,576);
  
  image(save[imgfaites-1],101,101);
  
 } 
  
  if(touche['2']==true && pressedimg==true && save.length>0) {
  
  pressedimg=false;
  background(255);
 
  image(savex,101,101);
    
  }
  
  
  
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Animator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
