import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Demineur extends PApplet {

 public void settings() {
  size(displayWidth/6*3/2,displayHeight/10*6);
}
   
int mine;
int mineale;

boolean start=false;

PImage bombe;
int comptl;
int comptc;
PImage logo;
int debut=-1;
int g=1;
int gros;

int fin;
PImage gameover;

int finish;
PImage drapeau;

int explofin2;

boolean triche;
public void setup() {
  explo2 = new SpriteAnim("explo.png",4,10,500,500,0);
  drapeau = loadImage("drap.png");
  gameover = loadImage("gameover.png");
  bombe = loadImage("bombe.png");
  explo = new SpriteAnim("explo.png",4,10,500,500,0);
  for(int i=0;i<exploperdre.length;i++) {
    exploperdre[i] = new SpriteAnim("explo.png",4,10,500,500,0);
  }
  logo =loadImage("logobase.png");
  

for(int i=0;i<400;i++) {
Cases[i] = new cases(comptl,comptc,0);
comptl++;

if(comptl==20) {
 comptl=0;
 comptc++;
} 
}


for(int i=0;i<blancs.length;i++) {
blancs[i] = new proj(width/3+width/6,width/12);
}
  
  
  
  
  
} 
 



public void draw(){
background(255);


if(debut<255 && debut>=0) {
 debut++; 
 
 if(gros>10 || gros<-10) {
  g=-g; 
 }
 
 
 gros=gros+g;
 tint(255,255-debut);
 image(bombe,width/3+width/12-gros/2,0+gros,width/6+gros,width/6-gros);
}

else {


tint(255,255);
image(logo,-width/40,-width/15,width,width/2);

explo.anim(width/3+width/12,0,width/6,width/6);

for(int i=0;i<Cases.length;i++) {
 Cases[i].aff(); 
}




if(debut>-250) {
if(debut>200) { debut=-1;}
debut--;
  
for(int i=0;i<blancs.length;i++) {
 blancs[i].lance(); 
 }
}

if(mineperdue!=-1) {
 
  explo2.anim(Cases[mineperdue].ligne*width/20-width/40+1,height-width+Cases[mineperdue].colo*width/20-width/40,width/10,width/10);
  
  for(int i=0;i<Cases.length;i++) {
  if(Cases[i].explofin>0) { exploperdre[Cases[i].explofin].anim(Cases[i].ligne*width/20-width/40+1,height-width+Cases[i].colo*width/20-width/40,width/10,width/10); }
  }
  
  
 if(explofin2<80) {
   
   for(int i=0;i<Cases.length;i++) {
 if(Cases[i].explofin==0 && Cases[i].type==10 && i!=mineperdue) {
 
   Cases[i].explofin=explofin2;
   i=Cases.length;
   
    }
   }
 explofin2++;
 }
 
 
 
 
 if(fin>100 && fin <300) {
 noStroke();
 fill(20,0+fin-80);
 rect(0,0,width,height);
 fill(255);
 stroke(0);
 }
 
 if(fin>=300) {
 noStroke();
 fill(20,220);
 rect(0,0,width,height);
 fill(255);
 stroke(0);
 }
 
if(fin<350 && fin>200) {
 
 image(gameover,width/16,-width*3/2+fin*2.5f,width,width/2);
  
}

   if(fin<350){
     
 fin++;
 mine=0;
 mineale=0;
 comptl=0;
 comptc=0;
 
 }
 else {
 fill(255);
 image(gameover,width/16,-width*3/2+350*2.5f,width,width/2);
 fill(0);
 text("'ESPACE'",width/2-width/40,height/3*2-width/40);
 
 if(keyPressed==true && key==' ') {
 




explofin2=0;
mineperdue=-1;
fin=0;
finish=0;   
start=false;
   
   for(int i=0;i<400;i++) {
Cases[i] = new cases(comptl,comptc,0);
comptl++;

if(comptl==20) {
 comptl=0;
 comptc++;
} 
}



for(int i=0;i<blancs.length;i++) {
blancs[i] = new proj(width/3+width/6,width/12);
}
   
   
   
   
   
   
   
 }
 
 }
 
 //fin de détection quand la mine perdante est touchée 
}




 }
 
 
 
 
 
 if(finish!=400 && fin==0) {finish=0;
 for(int i=0;i<Cases.length;i++) {
 if(Cases[i].clic==100 || Cases[i].type==10) {
 finish++;
 } 
}
 }
 
 //if(finish==400) {
 
 //}
 

   
   
   
 
  }
 
 
 


cases[] Cases = new cases[400];

class cases{
 int ligne;
 int colo;
 int type;
 int clic;
 boolean drap;
 int explofin;
 cases(int l,int c, int t) {
  ligne=l;
  colo=c;
  type=t;
 }
  
  public void aff() {
    
   fill(ligne*2+colo*2+20-clic);
   
   if(type==10 && finish==400) {fill(255,0,0);}
   
   if(triche==true && type==10) {fill(255,0,0);}
   
   rect(ligne*width/20-1,height-width+colo*width/20-1,width/20,width/20);
   
   if(type==1 && clic==100) { fill(0,0,200); text("1",ligne*width/20+width/50,width/30+height-width+colo*width/20-1); fill(255);}
   if(type==2 && clic==100) { fill(0,255,0); text("2",ligne*width/20+width/50,width/30+height-width+colo*width/20-1); fill(255);}
   if(type==3 && clic==100) { fill(255,0,0); text("3",ligne*width/20+width/50,width/30+height-width+colo*width/20-1); fill(255);}
   if(type==4 && clic==100) { fill(0,0,255); text("4",ligne*width/20+width/50,width/30+height-width+colo*width/20-1); fill(255);}
   if(type==5 && clic==100) { fill(0,0,200); text("5",ligne*width/20+width/50,width/30+height-width+colo*width/20-1); fill(255);}
   if(type==6 && clic==100) { fill(0,255,0); text("6",ligne*width/20+width/50,width/30+height-width+colo*width/20-1); fill(255);}
   if(type==7 && clic==100) { fill(255,0,0); text("7",ligne*width/20+width/50,width/30+height-width+colo*width/20-1); fill(255);}
   if(type==8 && clic==100) { fill(0,0,0); text("8",ligne*width/20+width/50,width/30+height-width+colo*width/20-1); fill(255);}
   
   if(drap==true) { image(drapeau,ligne*width/20-1,height-width+colo*width/20-1,width/20,width/20); }
   
   
  }
  
}
public void moins(int i) {

Cases[i].clic=100; 
  
if(i>0) {
if(Cases[i-1].type==10 && Cases[i].ligne>0) {Cases[i].type++;}
if(i>20) {if(Cases[i-20].type==10) {Cases[i].type++;}      
if(i>21) {if(Cases[i-21].type==10 && Cases[i].ligne>0 ) {Cases[i].type++;}   }
if(Cases[i-19].type==10 && Cases[i].ligne<19 ) {Cases[i].type++;} 
      }
}
      if(i<399) {
if(Cases[i+1].type==10 && Cases[i].ligne<19) {Cases[i].type++;}
if(i<379) {if(Cases[i+20].type==10) {Cases[i].type++;} 
if(i<378) {if(Cases[i+21].type==10 && Cases[i].ligne<19) {Cases[i].type++;} }
if(Cases[i+19].type==10  && Cases[i].ligne>0) {Cases[i].type++;} 
    }
   }
      
     
   if(Cases[i].type==0) {   
        
     //if(i>0) {if(Cases[i-1].clic==0 && Cases[i].ligne>0) {  moins(i-1); }} 
     //if(i<399) {if(Cases[i+1].clic==0 && Cases[i].ligne<19) {   moins(i+1); }} 
     //if(i>20) {if(Cases[i-20].clic==0) {   moins(i-20); }} 
     //if(i<379) {if(Cases[i+20].clic==0) {   moins(i+20); }} 
     
     if(i>0) {
if(Cases[i-1].clic==0 && Cases[i].ligne>0) {moins(i-1);}
if(i>=20) {if(Cases[i-20].clic==0) {moins(i-20);}      
if(i>=21) {if(Cases[i-21].clic==0 && Cases[i].ligne>0 ) {moins(i-21);}   }
if(Cases[i-19].clic==0 && Cases[i].ligne<19 ) {moins(i-19);} 
      }
}
      if(i<399) {
if(Cases[i+1].clic==0 && Cases[i].ligne<19) {moins(i+1);}
if(i<379) {if(Cases[i+20].clic==0) {moins(i+20);} 
if(i<378) {if(Cases[i+21].clic==0 && Cases[i].ligne<19) {moins(i+21);} }
if(Cases[i+19].clic==0  && Cases[i].ligne>0) {moins(i+19);} 
    }
   }
     
     
   }  
  
  
  
  
} 
  
int mineperdue=-1;
public void mousePressed() {
  
  if(mouseButton==CENTER) { if(triche==false) {triche=true;} else {triche=false;} }
  
  
  
  
  
  
  
 if(mouseY>height-width && mineperdue==-1 && mouseButton==LEFT) {
   for(int i=0;i<Cases.length;i++) {
     if(Cases[i].colo==-PApplet.parseInt(mouseY/( height-height-width/20)+7) && Cases[i].clic==0) {
       
     if(Cases[i].ligne==PApplet.parseInt(mouseX/( width/20)))  {
     
       Cases[i].drap=false;
       
     if(start==false) {
       
     Cases[i].clic=100;
  while(mine<80) {
  mineale=PApplet.parseInt(random(0,400));
  if(Cases[mineale].type==0 && Cases[mineale].clic==0) {
  Cases[mineale].type=10;
  mine++;
  }
 }
 Cases[i].clic=0;
 start=true;
}


       
      if(Cases[i].type==10) { 
       mineperdue=i;
       finish=400;
      }
      else {
      
        moins(i);
       
}
      
      
      
      

     }
    
   }
   
 }
  
 }

if(mouseY>height-width && mineperdue==-1 && mouseButton==RIGHT) {
  for(int i=0;i<Cases.length;i++) {
     if(Cases[i].colo==-PApplet.parseInt(mouseY/( height-height-width/20)+7) && Cases[i].clic==0) {
       
     if(Cases[i].ligne==PApplet.parseInt(mouseX/( width/20))) {

    if(Cases[i].drap==false) { Cases[i].drap=true;} else { Cases[i].drap=false; }
       
    }

   }

  }
}

}

SpriteAnim explo;
SpriteAnim[] exploperdre= new SpriteAnim[80];
SpriteAnim explo2;

class SpriteAnim {
  int index;
  int compt;
  int vit;
  int nbImg;
  PImage img;
  PImage[] tabImg;
  int Hauteur;
  int Longueur;
  int timeanim=0;
  int timeavantanim;
  SpriteAnim(String nomImg,int nbImage, int vitAnim, int L, int H,int timeavant){
    index=0;
    compt=0;
    vit=vitAnim;
    nbImg=nbImage;
    img=loadImage(nomImg);
    Hauteur=H;
    Longueur=L;
    tabImg=new PImage[nbImage];
    timeavantanim=timeavant;
    for (int i=0;i<nbImg;i++){
      tabImg[i]=img.get(Longueur*i,0,Longueur,Hauteur);
    }
  }
  public void anim(float x, float y, float tx, float ty){
     if(timeanim>timeavantanim) {
     compt++;
    if (compt==vit){
      compt=0;
      index=index+1;
      if (index==nbImg){
        index=0;
        timeanim=0;
      }
    }
  }
  
    timeanim=timeanim+1;
    image(tabImg[index],x,y,tx,ty);
  }
}


proj[] blancs = new proj[50];

class proj {
 float dy,dx,x,y; 
 int taille;
 
 proj(float xp,float yp){
   while((dy>-1 && dy<1)||(dx>-1 && dx<1)) {
   dy=random(-20,20);
   dx=random(-20,20);
 }
 x=xp;
 y=yp;
 }
 
 public void lance() {
  x=x+dx;
  y=y+dy;
  taille++;
  noStroke();
  fill(random(100,200));
  ellipse(x,y,width/20+taille,width/20+taille);
  stroke(0);
 }
  
  
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Demineur" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
